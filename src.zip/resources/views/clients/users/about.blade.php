@extends('layouts.users.master')
@section('content')
    <div class="container mt-5"></div>
@endsection
@push('scripts')
    <script src="{{ asset('js/users/about.js') }}" type="module"></script>
@endpush
